<?php
/**
 * Plugin Name: Weart Share
 * Plugin URI: http://themeforest.net/user/weartstudio
 * Description: Sharing buttons for The Balaton Theme.
 * Version: 1.0
 * Author: Weart Studio
 * Author URI: http://weartstudio.eu
 * License: GNU General Public License v3 or later
 */

function weart_share() {
  ?>
  <div class="weart-share lh-white">
    <!-- facebook -->
      <a class="bgh-black" href="https://www.facebook.com/sharer/sharer.php" onclick="var sharerFb = 'https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink() ?>'; window.open(sharerFb, 'sharerFb', 'width=626,height=436'); return false;"><i class="fab fa-facebook"></i></a>
    <!-- end -->

    <!-- Twitter -->
      <a class="bgh-black" href="https://twitter.com/share" onclick="var sharerTw = 'https://twitter.com/share?text=<?php the_title() ?>&amp;url=<?php the_permalink() ?>'; window.open(sharerTw, 'sharerTw', 'width=550,height=520'); return false;"><i class="fab fa-twitter"></i></a>
    <!-- end -->

    <!-- Reddit -->
      <a class="bgh-black" href="https://www.reddit.com/submit" onclick="var sharerRd = 'https://www.reddit.com/submit?url=<?php the_permalink() ?>&amp;title=<?php the_title() ?>'; window.open(sharerRd, 'sharerRd', 'width=840,height=464'); return false;"><i class="fab fa-reddit"></i></a>
    <!-- end -->

    <!-- Tumblr -->
      <a class="bgh-black" href="https://www.tumblr.com/share" onclick="var sharerTb = 'https://www.tumblr.com/share/link?url='; window.open(sharerTb + encodeURIComponent ( location.href ), 'sharerTb', 'width=450,height=430'); return false;"><i class="fab fa-tumblr"></i></a>
    <!-- end -->
  </div>
  <?php
}