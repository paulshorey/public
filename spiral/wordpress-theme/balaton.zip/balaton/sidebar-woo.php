<?php if ( is_active_sidebar( 'sidebar-woocommerce' ) ) { ?>
  <div class="sidebar col-lg-3 l-1 border-left">
    <div class="sidebar-inner">
      <?php dynamic_sidebar( 'sidebar-woocommerce' ); ?>
    </div>
  </div>
<?php } ?>