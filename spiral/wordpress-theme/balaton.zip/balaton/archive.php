<?php get_header();

weart_sectionTitle(array('title'=> get_the_archive_title() ));
weart_section(array('layout'=>'layout_5','on'=>1));

get_footer() ?>