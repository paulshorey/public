<?php if ( is_active_sidebar( 'sidebar-insta') ) { ?>
  <div id="insta-sidebar" class=" d-none d-md-block w-100">
      <?php dynamic_sidebar( 'sidebar-insta' ); ?>
  </div>
<?php } ?>