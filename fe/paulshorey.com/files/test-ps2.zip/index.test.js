var expect  = require('chai').expect;

const packagesToString = require('./index');

// DOES IT LOAD?
describe("Does it load?",function(){

	it('INPUT nothing, OUTPUT must be String', function(done) {
		const string = packagesToString();
		expect(typeof string === 'string').to.equal(true);
		done();
	});

});

// DOES IT WORK?
describe("Does it function?",function(){

	it('INPUT invalid, OUTPUT should fail and throw error', function (done) {
		const inputs = "adlkfjdfkdlj";
		// console.log("test result: `"+packagesToString(inputs)+"`");
		try {
			const string = packagesToString(inputs);
			expect(string, "input is invalid - this is the output: "+string).to.equal(false);
		} catch(e) {
		}
		done();
	});

	it('INPUT single value, OUTPUT must match inputs', function (done) {
		const packageName = "newPackage";
		// console.log("test result: `"+packagesToString([packageName])+"`");
		const string = packagesToString([packageName]);
		expect(string.indexOf(packageName) > -1, "package name not found").to.equal(true);
		done();
	});

	it('INPUT multiple values, OUTPUT comma separated', function (done) {
		const inputs = ["newPackage1","newPackage2"];
		// console.log("test result: `"+packagesToString(inputs)+"`");
		const string = packagesToString(inputs);
		expect(string.indexOf(",") > 0, "comma not found").to.equal(true);
		done();
	});

	it('INPUT with dependencies, OUTPUT should put the dependencies first', function (done) {
		const inputs = ["p1: something1","p2: something2","p3: something1"];
		// console.log("test result: `"+packagesToString(inputs)+"`");
		const string = packagesToString(inputs);
		expect(string.indexOf("something1") === 0, "`something1` should be first").to.equal(true);
		done();
	});

	it('INPUT with circular dependencies, OUTPUT should fail and throw error', function (done) {
		const inputs = ["p1: something1","p2: something2","p3: something1", "something1:p1"];
		// console.log("test result: `"+packagesToString(inputs)+"`");
		try {
			const string = packagesToString(inputs);
			expect(string, "this has uncaught circular dependency: "+string).to.equal(false);
		} catch(e) {
		}
		done();
	});

});