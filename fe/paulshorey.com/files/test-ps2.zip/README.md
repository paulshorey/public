# Interview assignment by PAUL SHOREY for PLURALSIGHT (v2)

> INPUT: array of packages and their dependencies 

> OUTPUT: a comma-separated string of packages in order of which to load first so as to not break anything

## Test

Now using Mocha + Chai. To start tests, run:
```
npm test
```


## Use

```js
const packagesToString = require('packages-to-string')
console.log(packagesToString())
// 

console.log(packagesToString(["somePackage"]))
// somePackage 

console.log(packagesToString(["p1","p2","p3"]))
// p1, p2, p3 

console.log(packagesToString(["p1: something1","p2: something2","p3: something1"]))
// something1, p1, something2, p2, p3 

console.log(packagesToString(["p1: something1","p2: something2","p3: something1","something1: p1"]))
// Error: circular dependency
```

## Repo at: 

Has been deleted from my GitHub. Sorry about that. Anyway, the way I did the tests were unorthodox, so wouldn't have helped another person, or would be obvious, if someone copied it. :)  
  
Repository started from <a href="https://github.com/gr2m/funky-sloth-42">https://github.com/gr2m/funky-sloth-42</a>, but only used as a template. No original code remains. 
 

